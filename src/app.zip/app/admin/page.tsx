"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/app/lib/supabase";
import Image from "next/image";

interface Visit {
  visit_id: string; student_id: string; reason: string;
  visit_date: string; visit_time: string;
  students: { name: string; college: string; employee_status: string; };
}

export default function AdminPage() {
  const router = useRouter();
  const [visits, setVisits] = useState<Visit[]>([]);
  const [filtered, setFiltered] = useState<Visit[]>([]);
  const [loading, setLoading] = useState(true);
  const [adminPassword, setAdminPassword] = useState("");
  const [authenticated, setAuthenticated] = useState(false);
  const [authError, setAuthError] = useState("");
  const [showPass, setShowPass] = useState(false);
  
  // Filters
  const [filterReason, setFilterReason] = useState("");
  const [filterCollege, setFilterCollege] = useState("");
  const [filterStatus, setFilterStatus] = useState("");
  const [filterDateFrom, setFilterDateFrom] = useState("");
  const [filterDateTo, setFilterDateTo] = useState("");

  const today = new Date().toISOString().split("T")[0];
  const weekAgo = new Date(Date.now() - 7 * 86400000).toISOString().split("T")[0];
  const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split("T")[0];
  
  const totalToday = visits.filter(v => v.visit_date === today).length;
  const totalWeek = visits.filter(v => v.visit_date >= weekAgo).length;
  const totalMonth = visits.filter(v => v.visit_date >= monthStart).length;

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPassword === "admin123") { 
        setAuthenticated(true); 
        fetchVisits(); 
    } else {
        setAuthError("Incorrect password. Please try again.");
    }
  };

  const fetchVisits = async () => {
    const { data, error } = await supabase.from("library_visits")
      .select(`*, students(name, college, employee_status)`)
      .order("visit_date", { ascending: false })
      .order("visit_time", { ascending: false });
    
    if (!error && data) { 
        setVisits(data as Visit[]); 
        setFiltered(data as Visit[]); 
    }
    setLoading(false);
  };

  useEffect(() => {
    let r = [...visits];
    if (filterReason) r = r.filter(v => v.reason === filterReason);
    if (filterCollege) r = r.filter(v => v.students?.college === filterCollege);
    if (filterStatus) r = r.filter(v => v.students?.employee_status === filterStatus);
    if (filterDateFrom) r = r.filter(v => v.visit_date >= filterDateFrom);
    if (filterDateTo) r = r.filter(v => v.visit_date <= filterDateTo);
    setFiltered(r);
  }, [filterReason, filterCollege, filterStatus, filterDateFrom, filterDateTo, visits]);

  const colleges = [...new Set(visits.map(v => v.students?.college).filter(Boolean))];
  const reasonData: Record<string, { icon: string; color: string; bg: string }> = {
    Studying: { icon: "📚", color: "text-blue-700", bg: "bg-blue-50" },
    "Borrowing Books": { icon: "📖", color: "text-emerald-700", bg: "bg-emerald-50" },
    Research: { icon: "🔬", color: "text-purple-700", bg: "bg-purple-50" },
    "Group Work": { icon: "👥", color: "text-amber-700", bg: "bg-amber-50" },
    Printing: { icon: "🖨️", color: "text-pink-700", bg: "bg-pink-50" },
  };

  // LOGIN SCREEN
  if (!authenticated) {
    return (
      <div className="min-h-screen w-full flex bg-gray-50 overflow-hidden" style={{ fontFamily: 'var(--font-body)' }}>
        {/* Left Side - Branding */}
        <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-red-950 via-red-900 to-red-800 relative overflow-hidden flex-col items-center justify-center">
          <div className="absolute top-[-120px] right-[-120px] w-[500px] h-[500px] rounded-full border border-white/10" />
          <div className="absolute bottom-[-150px] left-[-100px] w-[450px] h-[450px] rounded-full border border-white/10" />
          
          <div className="relative z-10 px-16 text-center flex flex-col items-center">
            <div className="w-40 h-40 rounded-full bg-white p-3 shadow-2xl shadow-yellow-500/20 mb-8 animate-bounce" style={{ animationDuration: '3s' }}>
              <Image src="/neu-library-logo.png" alt="NEU" width={160} height={160} className="w-full h-full object-contain rounded-full" />
            </div>
            <p className="text-yellow-400 text-xs font-bold tracking-[0.3em] uppercase mb-4">New Era University</p>
            <h1 className="text-5xl font-black text-white mb-2 tracking-tight">Admin Portal</h1>
            <h2 className="text-3xl font-medium text-white/80 mb-8">Library Dashboard</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-transparent via-yellow-400 to-transparent mx-auto rounded-full" />
          </div>
        </div>

        {/* Right Side - Login Form */}
        <div className="w-full lg:w-1/2 flex items-center justify-center p-8 relative">
          <div className="w-full max-w-md relative z-10">
            <div className="lg:hidden text-center mb-8">
              <div className="w-24 h-24 mx-auto mb-4 rounded-full bg-white p-2 shadow-xl shadow-red-900/10">
                <Image src="/neu-library-logo.png" alt="NEU" width={80} height={80} className="w-full h-full object-contain rounded-full" />
              </div>
            </div>

            <div className="bg-white rounded-3xl p-8 sm:p-10 shadow-2xl shadow-red-900/10 border border-gray-100">
              <div className="mb-8">
                <span className="inline-flex items-center gap-2 bg-red-50 text-red-700 text-xs font-bold px-3 py-1.5 rounded-full mb-4">
                  🔐 Restricted Access
                </span>
                <h2 className="text-3xl font-black text-gray-900">Admin Login</h2>
                <p className="text-gray-500 text-sm mt-2">Sign in to manage library records.</p>
              </div>

              {authError && (
                <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-3 mb-6 flex items-center gap-3">
                  <span className="text-red-500">⚠️</span>
                  <p className="text-red-700 text-sm font-medium">{authError}</p>
                </div>
              )}

              <form onSubmit={handleAdminLogin} className="space-y-6">
                <div>
                  <label className="block text-xs font-bold text-gray-500 tracking-widest uppercase mb-2">Password</label>
                  <div className="relative group">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-red-600 transition-colors">
                      🔑
                    </div>
                    <input 
                      type={showPass ? "text" : "password"} 
                      placeholder="Enter admin password"
                      value={adminPassword} 
                      onChange={e => setAdminPassword(e.target.value)}
                      className="w-full pl-12 pr-12 py-3.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-red-600/20 focus:border-red-600 focus:bg-white transition-all" 
                    />
                    <button type="button" onClick={() => setShowPass(!showPass)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 text-sm transition-colors">
                      {showPass ? "🙈" : "👁️"}
                    </button>
                  </div>
                </div>
                
                <button type="submit"
                  className="w-full bg-red-800 hover:bg-red-900 text-white font-bold py-3.5 rounded-xl text-sm transition-all shadow-lg shadow-red-900/20 hover:shadow-red-900/40 active:scale-[0.98]">
                  Access Dashboard →
                </button>
              </form>
              
              <button onClick={() => router.push("/login")} className="w-full mt-6 text-sm font-medium text-gray-500 hover:text-gray-800 transition-colors">
                ← Back to Student Login
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // DASHBOARD
  return (
    <div className="min-h-screen bg-gray-50 pb-12" style={{ fontFamily: 'var(--font-body)' }}>
      {/* Navbar */}
      <nav className="bg-red-900 sticky top-0 z-50 shadow-lg shadow-red-900/20">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-white p-1 shadow-inner">
              <Image src="/neu-library-logo.png" alt="NEU" width={40} height={40} className="w-full h-full object-contain rounded-full" />
            </div>
            <div>
              <h1 className="text-white font-black text-lg leading-tight tracking-tight">NEU Library</h1>
              <p className="text-red-200 text-xs font-medium">Admin Dashboard</p>
            </div>
          </div>
          <div className="flex items-center gap-6">
            <div className="hidden md:flex items-center gap-2 bg-red-950/50 rounded-full px-4 py-1.5 border border-red-800">
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              <span className="text-red-100 text-xs font-medium">Authorized Admin</span>
            </div>
            <button onClick={() => router.push("/login")}
              className="bg-white/10 hover:bg-white/20 border border-white/20 text-white font-semibold px-5 py-2 rounded-lg text-sm transition-all">
              Log Out
            </button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-6 pt-8 space-y-8">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { label: "Visitors Today", value: totalToday, icon: "👥", gradient: "from-red-800 to-red-600", sub: today },
            { label: "Visitors This Week", value: totalWeek, icon: "📅", gradient: "from-amber-500 to-orange-500", sub: "Last 7 days" },
            { label: "Visitors This Month", value: totalMonth, icon: "📊", gradient: "from-emerald-600 to-teal-500", sub: new Date().toLocaleString("default", { month: "long", year: "numeric" }) },
          ].map((card, i) => (
            <div key={card.label}
              className={`bg-gradient-to-br ${card.gradient} rounded-2xl p-6 text-white shadow-xl shadow-gray-200 relative overflow-hidden hover:-translate-y-1 transition-transform duration-300`}>
              <div className="absolute top-[-20px] right-[-20px] w-32 h-32 rounded-full bg-white/10" />
              <div className="flex justify-between items-start mb-6 relative z-10">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center text-2xl backdrop-blur-sm">
                  {card.icon}
                </div>
                <span className="bg-white/20 backdrop-blur-sm text-white text-xs font-semibold px-3 py-1.5 rounded-full">{card.sub}</span>
              </div>
              <p className="text-5xl font-black mb-1 relative z-10">{card.value}</p>
              <p className="text-white/80 text-sm font-medium relative z-10">{card.label}</p>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="font-black text-gray-800 text-lg">Filter Records</h2>
              <p className="text-gray-500 text-sm mt-1">Narrow down visitor data</p>
            </div>
            <button onClick={() => { setFilterReason(""); setFilterCollege(""); setFilterStatus(""); setFilterDateFrom(""); setFilterDateTo(""); }}
              className="text-sm text-red-600 hover:text-red-800 hover:bg-red-50 font-bold px-4 py-2 rounded-lg transition-colors border border-transparent hover:border-red-100">
              Clear Filters ✕
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {[
              { value: filterReason, onChange: setFilterReason, options: ["Studying","Borrowing Books","Research","Group Work","Printing"], placeholder: "🔍 All Reasons" },
              { value: filterCollege, onChange: setFilterCollege, options: colleges as string[], placeholder: "🏛️ All Colleges" },
              { value: filterStatus, onChange: setFilterStatus, options: ["Student","Faculty","Staff"], placeholder: "👤 All Status" },
            ].map((f, i) => (
              <select key={i} value={f.value} onChange={e => f.onChange(e.target.value)}
                className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-700 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-red-600/20 focus:border-red-600 focus:bg-white transition-all font-medium appearance-none">
                <option value="">{f.placeholder}</option>
                {f.options.map(o => <option key={o}>{o}</option>)}
              </select>
            ))}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs text-gray-500 font-bold uppercase tracking-wider ml-1">Date From</label>
              <input type="date" value={filterDateFrom} onChange={e => setFilterDateFrom(e.target.value)}
                className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm text-gray-700 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-red-600/20 focus:border-red-600 focus:bg-white transition-all font-medium" />
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-xs text-gray-500 font-bold uppercase tracking-wider ml-1">Date To</label>
              <input type="date" value={filterDateTo} onChange={e => setFilterDateTo(e.target.value)}
                className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm text-gray-700 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-red-600/20 focus:border-red-600 focus:bg-white transition-all font-medium" />
            </div>
          </div>
        </div>

        {/* Table */}
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden flex flex-col">
          <div className="px-6 py-5 border-b border-gray-200 flex flex-wrap justify-between items-center gap-4 bg-gray-50/50">
            <div>
              <h2 className="font-black text-gray-800 text-lg">Visitor Records</h2>
              <p className="text-gray-500 text-sm mt-1">All library check-ins</p>
            </div>
            <div className="flex items-center gap-2 bg-white border border-gray-200 px-4 py-2 rounded-lg shadow-sm">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span className="text-sm text-gray-600 font-semibold">
                Showing {filtered.length} of {visits.length} records
              </span>
            </div>
          </div>

          {loading ? (
            <div className="text-center py-32 bg-white">
              <div className="text-4xl mb-4 animate-spin inline-block">⏳</div>
              <p className="text-gray-500 font-medium">Loading library records...</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left whitespace-nowrap">
                <thead className="text-xs text-gray-500 uppercase bg-gray-50 border-b border-gray-200">
                  <tr>
                    {["Student Name", "College", "Status", "Reason", "Date", "Time"].map(h => (
                      <th key={h} className="px-6 py-4 font-bold tracking-wider">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {filtered.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="text-center py-24 bg-white">
                        <div className="text-5xl mb-4 text-gray-300">🔍</div>
                        <p className="text-lg font-bold text-gray-600">No records found</p>
                        <p className="text-gray-500 text-sm mt-1">Try adjusting your filters above.</p>
                      </td>
                    </tr>
                  ) : filtered.map((visit) => (
                    <tr key={visit.visit_id} className="hover:bg-red-50/40 transition-colors bg-white">
                      <td className="px-6 py-4 font-bold text-gray-900">
                        {visit.students?.name || "—"}
                      </td>
                      <td className="px-6 py-4 text-gray-600 font-medium">
                        {visit.students?.college || "—"}
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-bold ${
                          visit.students?.employee_status === "Faculty" ? "bg-blue-50 text-blue-700 border border-blue-100" :
                          visit.students?.employee_status === "Staff" ? "bg-purple-50 text-purple-700 border border-purple-100" :
                          "bg-emerald-50 text-emerald-700 border border-emerald-100"}`}>
                          {visit.students?.employee_status || "Student"}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        {visit.reason && reasonData[visit.reason] ? (
                          <span className={`inline-flex items-center gap-1.5 font-bold text-xs px-3 py-1 rounded-full border border-gray-100 ${reasonData[visit.reason].bg} ${reasonData[visit.reason].color}`}>
                            {reasonData[visit.reason].icon} {visit.reason}
                          </span>
                        ) : <span className="text-gray-400 italic text-xs">Not specified</span>}
                      </td>
                      <td className="px-6 py-4 text-gray-500 font-semibold">{visit.visit_date}</td>
                      <td className="px-6 py-4 text-gray-500 font-semibold">{visit.visit_time}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}